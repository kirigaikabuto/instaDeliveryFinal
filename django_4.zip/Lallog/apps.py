from django.apps import AppConfig


class LallogConfig(AppConfig):
    name = 'Lallog'
