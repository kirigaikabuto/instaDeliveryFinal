from django.contrib import admin
from .models import AdminModel
# Register your models here.

admin.site.register(AdminModel)