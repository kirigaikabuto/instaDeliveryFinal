from django.apps import AppConfig


class CurierConfig(AppConfig):
    name = 'curier'
